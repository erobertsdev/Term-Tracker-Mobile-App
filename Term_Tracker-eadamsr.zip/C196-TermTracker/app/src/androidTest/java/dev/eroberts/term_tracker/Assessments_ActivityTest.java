package dev.eroberts.term_tracker;

import junit.framework.TestCase;

public class Assessments_ActivityTest extends TestCase {

    public void testOnCreate() {
    }

    public void testOnActivityResult() {
    }

    public void testOnSupportNavigateUp() {
    }
}